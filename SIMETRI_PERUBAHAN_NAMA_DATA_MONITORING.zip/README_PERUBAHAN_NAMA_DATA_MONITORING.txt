SIMETRI — PERUBAHAN ISTILAH MONITORING PUBLIK

Perubahan:
- Monitoring Publik -> Data Monitoring
- Pantau rekap penelitian, publikasi, luaran, pengabdian, pendanaan, dan capaian PPEPP tanpa login.
  -> Rekap penelitian & pengabdian, publikasi, dan pendanaan.
- Monitoring & Rekap Publik -> Monitoring & Rekap Data
- Lihat Monitoring Publik -> Lihat Data Monitoring

Tidak ada perubahan SQL/database.

Timpa:
1. src/App.jsx
2. src/components/PublicMonitoringDashboard.jsx

Lalu:
npm.cmd run dev
